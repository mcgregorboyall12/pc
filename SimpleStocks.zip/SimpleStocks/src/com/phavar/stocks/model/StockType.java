package com.phavar.stocks.model;

/**
 * Constants for stock types
 * 
 * @author Panagiotis Chavariotis
 *
 */

public enum StockType {
	/**
	 * The stock is "common" and the dividend yield is calculated with last dividend.
	 */
	COMMON,
	
	/**
	 * The stock is "preferred" and the dividend yield is calculated with fixed dividend.
	 */
	PREFERRED
} 