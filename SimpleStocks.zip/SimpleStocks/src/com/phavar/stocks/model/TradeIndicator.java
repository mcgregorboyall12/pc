package com.phavar.stocks.model;

/**
 * Constants for the buy or sell indicator associated to a trade.
 * 
 * @author Panagiotis Chavariotis
 *
 */

public enum TradeIndicator {
	/**
	 * Indicates that a trade represents a BUY of shares for a specific stock.
	 */
	BUY,
	
	/**
	 * Indicates that a trade represents a SELL of shares for a specific stock.
	 */
	SELL
} 
