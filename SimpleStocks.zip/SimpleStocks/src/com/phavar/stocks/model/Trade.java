package com.phavar.stocks.model;

import java.time.LocalDateTime; 

/**
 * 
 * @author Panagiotis Chavariotis
 *
 */

public class Trade {
	/**
	 * 
	 */
	private LocalDateTime dateTime = null;
	
	/**
	 * 
	 */
	private Stock stock = null;
	
	/**
	 * 
	 */
	private TradeIndicator tradeIndicator = TradeIndicator.BUY;
	
	/**
	 * 
	 */
	private int sharesQuantity = 0;
	
	/**
	 * 
	 */
	private double price = 0.0;
	
	
	/**
	 * 
	 */
	public Trade(){
	}
	
	/**
	 * 
	 * @return
	 */
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	
	/**
	 * 
	 * @param dateTime
	 */
	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	
	/**
	 * 
	 * @return
	 */
	public int getSharesQuantity() {
		return sharesQuantity;
	}
	
	/**
	 * 
	 * @param sharesQuantity
	 */
	public void setSharesQuantity(int sharesQuantity) {
		this.sharesQuantity = sharesQuantity;
	}
	
	/**
	 * 
	 * @return
	 */
	public TradeIndicator getTradeIndicator() {
		return tradeIndicator;
	}
	
	/**
	 * 
	 * @param tradeIndicator
	 */
	public void setTradeIndicator(TradeIndicator tradeIndicator) {
		this.tradeIndicator = tradeIndicator;
	}
	
	/**
	 * 
	 * @return
	 */
	public double getPrice() {
		return price;
	}
	
	/**
	 * 
	 * @param price
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/**
	 * 
	 * @return
	 */
	public Stock getStock() {
		return stock;
	}
	
	/**
	 * 
	 * @param stock
	 */
	public void setStock(Stock stock) {
		this.stock = stock;
	}

	@Override
	public String toString() {
		String pattern = "Trade Object [timeStamp: %tF %tT, stock: %s, indicator: %s, shares quantity: %7d, price: %8.2f]";
		return String.format(pattern, dateTime, dateTime, stock, tradeIndicator, sharesQuantity, price);
	}
}
