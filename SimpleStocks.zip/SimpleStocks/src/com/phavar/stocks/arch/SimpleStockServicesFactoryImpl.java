package com.phavar.stocks.arch;

import com.phavar.stocks.service.SimpleStockService;

/**
 * 
 * @author Panagiotis Chavariotis
 *
 */
public class SimpleStockServicesFactoryImpl implements SimpleStockServicesFactory {
	
	/**
	 * The constructor is private in order to prevent new instance
	 */
	private SimpleStockServicesFactoryImpl(){
		SpringService.INSTANCE.getClass();
	}

	private static class SimpleStockServicesFactoryHolder{
		private static final SimpleStockServicesFactory INSTANCE = new SimpleStockServicesFactoryImpl();
	}

	public static SimpleStockServicesFactory getInstance(){
		return SimpleStockServicesFactoryHolder.INSTANCE;
	}
	
	public SimpleStockService getSimpleStockService() {
		return SpringService.INSTANCE.getBean("simpleStocksService", SimpleStockService.class); 
	}

}
