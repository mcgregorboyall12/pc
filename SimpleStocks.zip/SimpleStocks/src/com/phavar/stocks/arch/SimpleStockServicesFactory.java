package com.phavar.stocks.arch;

import com.phavar.stocks.arch.SimpleStockServicesFactoryImpl;
import com.phavar.stocks.service.SimpleStockService;

/**
 * All the available services should be accessed via this factory
 * 
 * @author Panagiotis Chavariotis
 *
 */
public interface SimpleStockServicesFactory {
	/**
	 * Singleton instance of the factory SimpleStockServicesFactory.
	 */
	public SimpleStockServicesFactory INSTANCE = SimpleStockServicesFactoryImpl.getInstance();
	
	/**
	 * Gets the singleton instance of the Simple Stock Service
	 * 
	 */
	public SimpleStockService getSimpleStockService(); 
}
