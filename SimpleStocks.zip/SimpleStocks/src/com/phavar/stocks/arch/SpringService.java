package com.phavar.stocks.arch;

/**
 * Access all classes and services configured in the Spring context. 
 * 
 * @author Panagiotis Chavariotis
 *
 */
public interface SpringService {
	/**
	 * Singleton instance of the SpringService.
	 */
	public SpringService INSTANCE = SpringServiceImpl.getInstance();	

	/**
	 * Retrieve an object of the bean configured in the Spring context with the name <i>beanName</i> and class <i>objectClass</i>.
	 * 
	 */
	public <T extends Object> T getBean(String beanName, Class<T> objectClass);

	/**
	 * Gets an object of the bean configured in the Spring context for the class <i>objectClass</i>.
	 * 
	 */
	public <T extends Object> T getBean(Class<T> objectClass); 
}
