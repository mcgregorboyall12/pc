package com.phavar.stocks.service;

import com.phavar.stocks.model.Trade;

/**
 * 
 * @author Paangiotis Chavariotis
 *
 */
public interface SimpleStockService {
	/**
	 * Calculates the dividend yield for a given stock.
	 */
	public double calculateDividendYield(String stockSymbol) throws Exception;
	
	/**
	 * Calculates the P/E Ratio for a given stock.
	 */
	public double calculatePERatio(String stockSymbol) throws Exception;
	
	/**
	 * Record a trade in the Simple Stocks application.
	 */
	public boolean recordTrade(Trade trade) throws Exception;
	
	/**
	 * 
	 */
	public double calculateStockPrice(String stockSymbol) throws Exception;
	
	/**
	 * Calculates the GBCE All Share Index using the geometric mean of prices for all stocks, based on the following assumptions.
	 * 
	 * a) Only the stocks with prices greater than zero would taken into consideration, due to geometric mean issue (cannot be defined) 
	 * b) If all the stock prices are zero then the value for the GBCE All Share Index is zero.
	 * 
	 * @return
	 * @throws Exception
	 */
	public double calculateGBCEAllShareIndex() throws Exception;
}
