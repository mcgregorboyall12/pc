package com.phavar.stocks.util;

import java.time.LocalDateTime;

/**
 * 
 * @author Panagiotis Chavariotis
 *
 */
public class DateUtilsImpl implements DateUtils {

	public LocalDateTime getNowPlusMinutes(int minutes) {
		LocalDateTime dateTime = LocalDateTime.now();
		return dateTime.plusMinutes(minutes);
	}

}
