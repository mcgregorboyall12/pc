package com.phavar.stocks.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.collections.Predicate;
import org.apache.log4j.Logger;

import com.phavar.stocks.model.Trade;

/**
 * 
 * @author Panagiotis Chavariotis
 *
 */
public class StockPredicate implements Predicate {
	
	private Logger logger = Logger.getLogger(StockPredicate.class);

	private String stockSymbol = "";

	private LocalDateTime dateRange = null;

	public StockPredicate(String stockSymbol, int minutesRange){
		this.stockSymbol = stockSymbol;
		if( minutesRange > 0 ){
			dateRange = LocalDateTime.now();
			dateRange.plusMinutes(-minutesRange);
			logger.debug("Filter date pivot: " + DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss").format(dateRange));
		}

	} 
	
	public boolean evaluate(Object tradeObject) {
		Trade trade = (Trade) tradeObject;
		boolean shouldBeIncluded = trade.getStock().getStockSymbol().equals(stockSymbol);
		if(shouldBeIncluded && dateRange != null){
			//shouldBeInclude = dateRange.getTime().compareTo(trade.getTimeStamp())<=0; 
			shouldBeIncluded = dateRange.isBefore(trade.getDateTime()) || dateRange.isEqual(trade.getDateTime());
		}
		return shouldBeIncluded; 
	}

}
