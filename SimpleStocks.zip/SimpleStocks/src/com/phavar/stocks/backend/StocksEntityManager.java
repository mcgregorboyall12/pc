package com.phavar.stocks.backend;

import java.util.ArrayList;
import java.util.HashMap;

import com.phavar.stocks.model.Stock;
import com.phavar.stocks.model.Trade; 

/**
 * The store service for the Stocks and Trades. It holds in memory all the information in the application. 
 * 
 * @author Panagiotis Chavariotis
 *
 */
public interface StocksEntityManager {
	/**
	 * Record in the Stock Entity Manager a trade represented by the object <i>trade</i>.
	 * 
	 */
	public boolean recordTrade(Trade trade) throws Exception;
	
	/**
	 * Gets the array list that contains all the trades.
	 * 
	 */
	public ArrayList<Trade> getTrades();
	
	/**
	 * 
	 */
	public Stock getStockBySymbol(String stockSymbol);
	
	/**
	 * Gets all the existing stocks in the Simple Stocks application.
	 * 
	 */
	public HashMap<String, Stock> getStocks(); 
}
