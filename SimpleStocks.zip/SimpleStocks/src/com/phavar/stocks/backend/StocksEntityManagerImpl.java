package com.phavar.stocks.backend;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.phavar.stocks.backend.StocksEntityManager;
import com.phavar.stocks.model.Stock;
import com.phavar.stocks.model.Trade;

/**
 * 
 * @author Panagiotis Chavariotis
 *
 */
public class StocksEntityManagerImpl implements StocksEntityManager {
	
	private Logger logger = Logger.getLogger(StocksEntityManagerImpl.class);

	private HashMap<String, Stock> stocks = null;

	private ArrayList<Trade> trades = null;

	public StocksEntityManagerImpl(){
		trades = new ArrayList<Trade>();
		stocks = new HashMap<String, Stock>();
	} 

	public boolean recordTrade(Trade trade) throws Exception {
		boolean result = false;
		try{
			result = trades.add(trade);
		}catch(Exception exception){
			throw new Exception("An error has occurred recording a trade in the system's backend.", exception);
		}
		return result; 
	}

	public ArrayList<Trade> getTrades() {
		return trades; 
	}
	
	public void setTrades(ArrayList<Trade> trades) {
		this.trades = trades;
	} 
	
	public Stock getStockBySymbol(String stockSymbol) {
		Stock stock = null;
		try{
			if(stockSymbol!=null){
				stock = stocks.get(stockSymbol);
			}
		}catch(Exception exception){
			logger.error("An error has occurred recovering the stock object for the stock symbol: " + stockSymbol + ".", exception);
		}
		return stock;
	}

	public HashMap<String, Stock> getStocks() {
		return stocks;
	}
	
	public void setStocks(HashMap<String, Stock> stocks) {
		this.stocks = stocks;
	} 
}
